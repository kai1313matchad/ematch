<style type="text/css">
	#map-canvas { height: 100% }
</style>
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-primary" data-collapsed="0">
        	<div class="panel-heading">
            	<div class="panel-title">
            		<i class="entypo-plus-circled"></i>
            		Add

            	</div>
            </div>
			<div class="panel-body">
				ini form beri keterangan
               <div id="map-canvas" style="max-width:500px;max-height: 300px;"/>

            </div>
        </div>
    </div>
</div>


<?php
	//panggil semua layout
	require_once('head.php');
	require_once('header.php');
	require_once('content.php');	
?>